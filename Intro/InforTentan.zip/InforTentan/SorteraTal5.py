listamedtal=[3,6,2,8,0]

#Listar från största till minsta tal
listamedtal.sort(reverse=True)
[print(i) for i in listamedtal]


#Listar från minsta till största taö
listamedtal.sort()
[print(i) for i in listamedtal]
