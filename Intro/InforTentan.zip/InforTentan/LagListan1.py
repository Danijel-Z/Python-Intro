class Team:

    def __init__(self,namn,antal_vunna,antal_förlorade,avgojrda_match):
        self._namn = namn

        self._antalvunna = int(antal_vunna)

        self._antalförlorade = int(antal_förlorade)

        self._avgjorda_match = int(avgojrda_match)


    def Poäng(self):
        resultat = self._antalvunna * 3 + self._avgjorda_match
        return resultat

    def skriv_ut (self):
        poäng= self.Poäng()

        utskrifta = f'{self._namn},{self._antalvunna},{self._avgjorda_match},{self._antalförlorade},{poäng}'
        utskrifta=utskrifta.split(',')

        return utskrifta


lista_team= []

while True:

    namn= input("Skriv in <Namn> <Antal vunna> <Antal förlorade> <Oavgjorda matcher>: ")

    if namn == "N" or namn == "n":

        for x in lista_team:
            print(x)
        break

    namn_1 , antal_vunna,antal_förlorade,avgjorde_match = namn.split()

    Fösta_team =Team(namn_1 , antal_vunna,antal_förlorade,avgjorde_match)

    lista_team.append(Fösta_team.skriv_ut())
